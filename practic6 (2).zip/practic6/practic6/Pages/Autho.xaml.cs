﻿using practic6.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace practic6.Pages
{
    /// <summary>
    /// Логика взаимодействия для Autho.xaml
    /// </summary>
    public partial class Autho : Page
    {
        int click;
        DispatcherTimer lockTimer;
        int remainingSeconds;

        public Autho()
        {
            InitializeComponent();
            click = 0;
            lockTimer = new DispatcherTimer();
            lockTimer.Interval = TimeSpan.FromSeconds(1);
            lockTimer.Tick += LockTimer_Tick;
        }

        private void btnEnterGuest_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Client(null));
        }


        private void btnEnter_Click(object sender, RoutedEventArgs e)
        {
            if (lockTimer.IsEnabled)
            {
                MessageBox.Show("Дождитесь завершения таймера.");
                return;
            }

            if (!IsWithinWorkingHours())
            {
                MessageBox.Show("Доступ к системе закрыт. Рабочее время с 10:00 до 19:00.");
                return;
            }

            click += 1;

            string login = tbLogin.Text.Trim();
            string password = Hash.HashPassword(tbPassword.Text.Trim());

            var context = AirlineEntities.GetContext();
            var user = context.Uesers.FirstOrDefault(x => x.Login == login && x.Password == password);
            if (click == 1)
            {

                if (user != null)
                {
                    var staffMember = context.Staf.FirstOrDefault(x => x.UserID == user.ID_User);
                    if (staffMember != null)
                    {
                        MessageBox.Show("Вы вошли под: " + user.User_roles.User_role_name.ToString());
                        GreetUser(staffMember, user);
                    }
                    else
                    {
                        MessageBox.Show("Не удалось найти информацию о сотруднике.");
                    }
                }
                else
                {
                    MessageBox.Show("Неверные данные. Попробуйте еще раз.");
                    tbPassword.Clear();
                    tbCaptcha.Clear();
                    GenerateCapctchas();
                }
            }
            else if (click <= 2)
            {
                if (user != null && tbCaptcha.Text == tblCaptcha.Text)
                {
                    var staffMember = context.Staf.FirstOrDefault(x => x.UserID == user.ID_User);
                    if (staffMember != null)
                    {
                        MessageBox.Show("Вы вошли под: " + user.User_roles.User_role_name.ToString());
                        GreetUser(staffMember, user);
                    }
                    else
                    {
                        MessageBox.Show("Не удалось найти информацию о сотруднике.");
                    }

                }
                else
                {
                    MessageBox.Show("Введите данные заново!");
                    tbPassword.Clear();
                    tbCaptcha.Clear();
                    GenerateCapctchas();
                }
            }
            else
            {
                remainingSeconds = 10;
                tbTimer.Text = $"Блокировка: {remainingSeconds} секунд";
                tbTimer.Visibility = Visibility.Visible;

                tbLogin.IsEnabled = false;
                tbPassword.IsEnabled = false;
                tbCaptcha.IsEnabled = false;
                btnEnter.IsEnabled = false;

                lockTimer.Start();
            }

        }

        private void LockTimer_Tick(object sender, EventArgs e)
        {
            remainingSeconds--;
            if (remainingSeconds > 0)
            {
                tbTimer.Text = $"Блокировка: {remainingSeconds} секунд";
            }
            else
            {
                lockTimer.Stop();
                tbTimer.Text = "";
                tbLogin.IsEnabled = true;
                tbPassword.IsEnabled = true;
                tbCaptcha.IsEnabled = true;
                btnEnter.IsEnabled = true;
                click = 0;
            }
        }

        private bool IsWithinWorkingHours()
        {
            var currentTime = DateTime.Now.TimeOfDay;
            var startTime = new TimeSpan(10, 0, 0);
            var endTime = new TimeSpan(19, 0, 0);

            return currentTime >= startTime && currentTime <= endTime;
        }

        private void LoadPage(string role, string greeting)
        {
            click = 0;
            ClearFields();

            switch (role)
            {
                case "Клиент":
                    NavigationService.Navigate(new Client(greeting));
                    break;
                case "Пилот":
                    NavigationService.Navigate(new Pilot(greeting));
                    break;
                case "Директор":
                    NavigationService.Navigate(new Director(greeting));
                    break;
                default:
                    MessageBox.Show("Роль не распознана.");
                    break;
            }
        }

        private void GenerateCapctchas()
        {
            tbCaptcha.Visibility = Visibility.Visible;
            tblCaptcha.Visibility = Visibility.Visible;
            string captchaText = CaptchaGenerator.GenerateCaptchaText(6);
            tblCaptcha.Text = captchaText;
            tblCaptcha.TextDecorations = TextDecorations.Strikethrough;
        }

        private void ClearFields()
        {
            tbLogin.Clear();
            tbPassword.Clear();
            tbCaptcha.Clear();
            tbCaptcha.Visibility = Visibility.Collapsed;
            tblCaptcha.Visibility = Visibility.Collapsed;
        }

        private void GreetUser(Staf staffMember, Uesers user)
        {
            string timeOfDay;
            var currentHour = DateTime.Now.Hour;

            if (currentHour >= 10 && currentHour <= 12)
                timeOfDay = "Доброе утро";
            else if (currentHour >= 12 && currentHour <= 17)
                timeOfDay = "Добрый день";
            else if (currentHour >= 17 && currentHour <= 19)
                timeOfDay = "Добрый вечер";
            else
                timeOfDay = "Вне рабочего времени";

            string greeting = $"{timeOfDay}, {staffMember.Name} {staffMember.Surname} " +
                              $"{(string.IsNullOrEmpty(staffMember.Patronymic) ? "" : staffMember.Patronymic)}!";
            LoadPage(user.User_roles.User_role_name.ToString(), greeting);
        }
    }
}
